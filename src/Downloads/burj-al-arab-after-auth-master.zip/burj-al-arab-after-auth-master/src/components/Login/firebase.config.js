const firebaseConfig = {
    apiKey: "AIzaSyAsihSADFnF_FoZ6je8p1W9lilyqX7cHWQ",
    authDomain: "burj-al-arab.firebaseapp.com",
    databaseURL: "https://burj-al-arab.firebaseio.com",
    projectId: "burj-al-arab",
    storageBucket: "burj-al-arab.appspot.com",
    messagingSenderId: "244522202387",
    appId: "1:244522202387:web:f3801d0588387140e1d6e6"
  };
  export default firebaseConfig;